﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BUSS.Models
{
    public class KeyValue
    {
        public string value1, value2;

        public KeyValue(string value1, string value2)
        {
            this.value1 = value1;
            this.value2 = value2;
        }
    }
}